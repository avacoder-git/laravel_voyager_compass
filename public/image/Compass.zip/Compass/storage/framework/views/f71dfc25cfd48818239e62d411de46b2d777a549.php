<?php $__env->startSection('content'); ?>

    <div class="p-100">
        <div class="main-header"><?php echo app('translator')->get('site.select_course'); ?></div>

        <div class="container-fluid p-0">
            <div class="row">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-6" data-aos="fade-up">
                        <div class="course mt-lg-5 mt-3 ">
                            <div class="course-img">
                                <img src="<?php echo e(imagePath($course->thumbnail)); ?>" alt="">
                            </div>
                            <div class="main-text mt-4  px-2 main-color">
                                <?php echo e($course->name); ?>

                            </div>
                            <div class="container-fluid lg-view main-color px-2 p-0">
                                <div class="row mt-2">
                                    <div class="col-4 p "><?php echo app('translator')->get('site.week'); ?></div>
                                    <div class="col-4 p ">| <?php echo e($course->weekly); ?> <?php echo app('translator')->get('site.ta'); ?></div>
                                    <div class="col-4 p "><?php echo e($course->sum); ?></div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-4 p "><?php echo app('translator')->get('site.lesson'); ?></div>
                                    <div class="col-4 p ">| <?php echo e($course->hours); ?> <?php echo app('translator')->get('site.hours'); ?></div>
                                    <div class="col-4 p "><?php echo app('translator')->get('site.sum'); ?></div>
                                </div>
                            </div>
                            <div class="d-lg-none px-2 mt-2 d-sm-block main-color">
                                <div class="p">
                                    <?php echo app('translator')->get('site.week'); ?> <?php echo e($course->weekly); ?> kun <br>
                                    <?php echo e($course->hours); ?> <?php echo app('translator')->get('site.hours'); ?> @la    ng('site.lesson')
                                </div>
                                <div class="main-text mt-2">
                                    <?php echo e($course->sum); ?> <?php echo app('translator')->get('site.sum'); ?>
                                </div>
                            </div>
                            <div class="text mt-3 lg-view px-2">
                                <?php echo e($course->description); ?>

                            </div>
                            <div class="p-2">
                                <button class="add course-<?php echo e($course->id); ?>" data-id="<?php echo e($course->id); ?>"><?php echo app('translator')->get('site.add'); ?> +</button>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


        </div>

        <div class="paginations">
            <?php echo e($courses->links()); ?>

        </div>
    </div>

    <form action="<?php echo e(route('register')); ?>" method="get">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="items" id="items">
        <button type="submit" class="register fill mainBtn"><?php echo app('translator')->get('site.register'); ?> <span class="reg-count"></span></button>

    </form>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <script>
        var storedArray = JSON.parse(sessionStorage.getItem("items"))??[0];//no brackets
        for (i = 0; i < storedArray.length; i++) {
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            if ($(".course-<?php echo e($course->id); ?>").data("id") == storedArray[i]){
                toggleAdd(".course-<?php echo e($course->id); ?>")
            }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        }
        count(storedArray)
        $(".add").click(function (){
            var id = $(this).data("id")

            storedArray = JSON.parse(sessionStorage.getItem("items"))??[0]//no brackets

            if ( !storedArray.includes(id)){
                storedArray.push(id)
            }else{
                storedArray = storedArray.filter(data => data != id);
            }
            sessionStorage.setItem("items", JSON.stringify(storedArray));
            $('#items').val(JSON.stringify(storedArray))
            count(storedArray)

        })



        function toggleAdd(className){
            var text = '<?php echo app('translator')->get('site.added'); ?> <i class="fas fa-check"></i>'
            $(className).toggleClass('added')
            if (!$(className).hasClass("added")){
                $(className).html("<?php echo app('translator')->get('site.add'); ?> +")
            }else {
                $(className).html(text)
            }
        }

        function count(arr){
            if (arr.length==1){
                var text = "";
            }else {
                var text = "("+(storedArray.length-1) + ")";
            }
            $('.reg-count').text(text);
        }
        $('#items').val(JSON.stringify(storedArray))


    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Compass\resources\views/site/courses.blade.php ENDPATH**/ ?>