<?php $__env->startSection("content"); ?>

    <div class="p-100">

        <div class="row justify-content-around">
            <div class="col-lg-3 col-6">
                <div class="info">
                    <div class="h-100"
                         style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                        <p class="quantity main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.bitiruvchilar')); ?></p>
                        <p class="main-color text-center t-mini mt-0 mb-auto" style="font-size: 18px">
                            <?php echo app('translator')->get('site.bitiruvchi'); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="info">
                    <div class="h-100"
                         style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                        <p class="quantity main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.student')); ?></p>
                        <p class="main-color text-center t-mini mt-0 mb-auto" style="font-size: 18px">
                            <?php echo app('translator')->get('site.bestudent'); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="info">
                    <div class="h-100"
                         style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                        <p class="quantity main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.ball')); ?></p>
                        <p class="main-color text-center t-mini mt-0 mb-auto" style="font-size: 18px">
                            <?php echo app('translator')->get('site.ball'); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="info">
                    <div class="h-100"
                         style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                        <p class="quantity main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.foreginer')); ?></p>
                        <p class="main-color text-center t-mini mt-0 mb-auto" style="font-size: 18px">
                            <?php echo app('translator')->get('site.foreigner'); ?></p>
                    </div>
                </div>
            </div>


        </div>


        <div class="main-header pt "><?php echo app('translator')->get('site.about'); ?></div>

        <div class="aboutus">

            <div class="container-fluid p-lg-0">
                <div class="row pt">
                    <div class="col-lg-6">
                        <img src="<?php echo e(asset("image/group.jpg")); ?>" alt="">
                    </div>
                    <div class="col-lg-6">
                        <div class="main-text third-color">
                           <?php echo app('translator')->get('site.section1'); ?>
                        </div>
                    </div>
                </div>
                <div class="row pt">
                    <div class="col-lg-6">
                        <div class="main-text third-color">
                            <?php echo app('translator')->get('site.section2'); ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <img src="<?php echo e(asset("image/group2.jpg")); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>


    </div>

    <div class="pt">

        <div class="keng-img">
            <img src="<?php echo e(asset("image/group3.jpg")); ?>" alt="">
        </div>


    </div>

    <div class="p-100 mb-5" >
        <div class="container-fluid aboutus p-lg-0">
            <div class="row">

                <div class="col-lg-12">
                    <div class="main-text third-color">
                        <?php echo app('translator')->get('site.section3'); ?>
                    </div>
                </div>
            </div>
            <div class="row pt">

                <div class="col-lg-6">
                    <div class="main-text third-color">
                        <?php echo app('translator')->get('site.section4'); ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <img src="<?php echo e(asset("image/group4.jpg")); ?>" alt="">
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Compass\resources\views/site/about.blade.php ENDPATH**/ ?>