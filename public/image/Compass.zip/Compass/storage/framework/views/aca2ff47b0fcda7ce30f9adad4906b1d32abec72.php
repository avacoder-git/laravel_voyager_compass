<?php $__env->startSection('style'); ?>

    <style>
        .emoji-smile{
            width: 250px;
            margin: 0 auto;
        }
    </style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="p-100">
        <div class="emoji-smile">
            <img src="<?php echo e(asset('image/emoji-smile.svg')); ?>" alt="">
        </div>
        <div class="mt-5">

            <div class="main-header text-center">
                Ariznangiz Muvaffaqiyatli Yuborlidi
            </div>
        </div>
        <div class=" mt-5 mx-auto text-center">
            <a href="/" class="mainBtn fill">Bosh sahifaga o'tish</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Compass\resources\views/site/success.blade.php ENDPATH**/ ?>