<?php $__env->startSection("content"); ?>


    <div class="container-fluid header">
        <div class="row">
            <div class="col-lg-6 part-1 p-0" style="">
                <div class="container-fluid">
                    <div class="col-12 p-0">
                        <div class="header-text header-anim" data-aos="zoom-out-right">
                            <?php echo app('translator')->get('site.main_text'); ?>
                        </div>
                    </div>
                    <div class="col-12 part-2 mt-5 px-0">
                        <div class="main-text second-color description-anim" data-aos="zoom-out-right"
                             data-aos-delay="300">
                            <?php echo app('translator')->get('site.description'); ?>
                        </div>
                        <div class="container-fluid">
                            <div class="row" style="margin-top: 54px">
                                <a href="" class="mainBtn fill"><?php echo app('translator')->get('site.write_course'); ?></a>
                                <a href="" class="mainBtn main-color bg-second fill2 ml-3"><?php echo app('translator')->get('site.contact'); ?></a>
                            </div>
                        </div>

                        <div class="container-fluid" data-aos="zoom-out-right" data-aos-delay="400">
                            <div class="row w-50 mt-3 justify-content-around">
                                <a href="" class="main-text second-color"><img src="<?php echo e(asset("image/location1.svg")); ?>"
                                                                               alt=""> <?php echo e(setting('site.address3')); ?></a>
                                <a href="" class="main-text second-color"><img src="<?php echo e(asset("image/location1.svg")); ?>"
                                                                               alt=""> <?php echo e(setting("site.address4")); ?></a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <img src="<?php echo e(asset("image/main%20photo.png")); ?>" data-aos="fade-up" style="width: 100%" alt="">
            </div>
            <div class="col-12 part-3 mt-5">
                <div class="main-text second-color">
                    <?php echo app('translator')->get('site.description'); ?>
                </div>
                <div class="container-fluid">
                    <div class="row  justify-content-around" style="margin-top: 54px">
                        <a href="" class="mainBtn fill"><?php echo app('translator')->get('site.write_course'); ?></a>
                        <a href="" class="mainBtn main-color bg-second fill2 ml-lg-3"><?php echo app('translator')->get('site.contact'); ?></a>
                    </div>
                </div>

                <div class="container-fluid">
                    <div class="row w-lg-50 mt-3 justify-content-around">
                        <a href="" class="main-text second-color"><img src="<?php echo e(asset("image/location1.svg")); ?>"
                                                                       alt=""><?php echo e(setting('site.address3')); ?></a>
                        <a href="" class="main-text second-color"><img src="<?php echo e(asset("image/location1.svg")); ?>"
                                                                       alt=""><?php echo e(setting("site.address4")); ?></a>
                    </div>

                </div>
            </div>

        </div>
    </div>


    <div class="container-fluid">

        <div class="row my-5 justify-content-center align-items-center">
            <div class="col-lg-2 col-6">
                <div class="sat">SAT</div>
            </div>
            <div class="col-lg-2 col-6">
                <div class="sat">IELTS</div>
            </div>
            <div class="col-lg-2 col-6">
                <div class="sat">ITPARK</div>
            </div>
            <div class="col-lg-2 col-6">
                <div class="sat"><?php echo app('translator')->get('site.president'); ?></div>
            </div>
            <div class="col-lg-2 col-6">
                <div class="sat">DTM</div>
            </div>
        </div>


    </div>


    <div class="container about">

        <div class="row my-5 py-lg-5 justify-content-around">
            <div class="col-lg-6 about-inner-lg">
                <div class="content1 position-relative">
                    <img src="<?php echo e(asset("image/Asset%201%201.png")); ?>" style="width: 100%" alt="">

                    <div class="content1-inner row justify-content-between">
                        <div class="counter">
                            <div class="h-100"
                                 style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                                <p class="main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.bitiruvchilar')); ?></p>
                                <p class="main-color text-center t-mini mt-0 mb-auto" style="font-size: 18px">
                                    <?php echo app('translator')->get('site.bitiruvchi'); ?></p>
                            </div>
                        </div>
                        <div class="counter">
                            <div class="h-100"
                                 style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                                <p class="main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.student')); ?></p>
                                <p class="main-color text-center t-mini mt-0 mb-auto"
                                   style="font-size: 18px"><?php echo app('translator')->get('site.bestudent'); ?></p>
                            </div>
                        </div>
                        <div class="counter">
                            <div class="h-100"
                                 style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                                <p class="main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.ball')); ?></p>
                                <p class="main-color text-center t-mini mt-0 mb-auto"
                                   style="font-size: 18px"><?php echo app('translator')->get('site.ball'); ?></p>
                            </div>
                        </div>
                        <div class="counter">
                            <div class="h-100"
                                 style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                                <p class="main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.foreginer')); ?></p>
                                <p class="main-color text-center t-mini mt-0 mb-auto"
                                   style="font-size: 18px"><?php echo app('translator')->get('site.foreigners'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 slide">
                <div class="main-header header-anim" data-aos="fade-up"><?php echo app('translator')->get('site.about'); ?></div>
                <div class="main-body mt-5 is-splited quote-anim" data-aos="fade-up">
                    <?php echo app('translator')->get('site.main1'); ?><br>
                    <?php echo app('translator')->get('site.main2'); ?>

                </div>
                <div class="about-inner-sm">
                    <div class="content1 position-relative">
                        <img src="<?php echo e(asset("image/Asset%201%201.png")); ?>" style="width: 100%" alt="">

                        <div class="content1-inner row justify-content-between">
                            <div class="counter">
                                <div class="h-100"
                                     style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                                    <p class="main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.bitiruvchilar')); ?></p>
                                    <p class="main-color text-center t-mini mt-0 mb-auto" style="font-size: 18px">
                                        <?php echo app('translator')->get('site.bitiruvchi'); ?></p>
                                </div>
                            </div>
                            <div class="counter">
                                <div class="h-100"
                                     style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                                    <p class="main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.student')); ?></p>
                                    <p class="main-color text-center t-mini mt-0 mb-auto"
                                       style="font-size: 18px"><?php echo app('translator')->get('site.bestudent'); ?></p>
                                </div>
                            </div>
                            <div class="counter">
                                <div class="h-100"
                                     style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                                    <p class="main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.ball')); ?></p>
                                    <p class="main-color text-center t-mini mt-0 mb-auto"
                                       style="font-size: 18px"><?php echo app('translator')->get('site.ball'); ?></p>
                                </div>
                            </div>
                            <div class="counter">
                                <div class="h-100"
                                     style="display: flex; align-items: center;height: 100vh;justify-content: center;flex-direction: column;">
                                    <p class="main-color main-text mb-0 mt-auto text-center"><?php echo e(setting('site.foreginer')); ?></p>
                                    <p class="main-color text-center t-mini mt-0 mb-auto" style="font-size: 18px">
                                        <?php echo app('translator')->get('site.foreigner'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="main-footer mt-5">
                    <a href="" class="mainBtn fill mt-3"><?php echo app('translator')->get('site.more'); ?></a>
                </div>
            </div>
        </div>


    </div>


    <div class="container-fluid p-100">
        <div class="main-header d-flex" data-aos="fade-up">
            <?php echo app('translator')->get('site.select_course'); ?>
            <a href="" class="main-color all-lg mt-auto ml-auto"
               style="font-size: 36px; font-family: Inter"><?php echo app('translator')->get('site.all'); ?></a>
        </div>

        <div class="row mt-1">

            <?php $__currentLoopData = \App\Models\Course::latest()->take(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4  col-6">
                    <div class="subject-card">
                        <div class="d-flex">
                            <div class="subject-img overflow-hidden"><img src="<?php echo e(imagePath($item->thumbnail)); ?>"
                                                                          height="100%" style="width: initial" alt="">
                            </div>
                            <div class="subject-content">
                                <div class="subject-header"><?php echo e($item->name); ?></div>
                                <div
                                    class="subject-info"><?php echo app('translator')->get('site.week'); ?> <?php echo e($item->weekly); ?> <?php echo app('translator')->get('site.day'); ?> <?php echo e($item->hours); ?> <?php echo app('translator')->get('site.hours'); ?> <?php echo app('translator')->get('site.lesson'); ?></div>
                                <div class="subject-body">
                                    100 dan ortiq o’quvchilar 6+ ball olishgan
                                </div>
                                <div class="subject-footer">
                                    <?php echo e($item->sum); ?> <?php echo app('translator')->get('site.sum'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="main-color all-sm text-center my-5"
                     style="font-size: 14px; font-family: Inter"><?php echo app('translator')->get('site.all'); ?>
                </div>
            </div>
        </div>


    </div>


    <section class="bg-main">
        <div class="p-100">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="main-header text-white header-sm header-anim"
                         data-aos="fade-up"><?php echo app('translator')->get('site.join'); ?></div>

                    <div>
                        <div
                            style="display: flex; flex-wrap: wrap; flex-direction: row; margin-left: -15px; margin-right: -15px; padding: 0 10px">

                            <div class="property col">
                                <div class="circle">
                                    <img src="<?php echo e(asset("image/rocket.svg")); ?>" alt="">
                                </div>
                                <div class="main-text text-center main-color">
                                    <?php echo app('translator')->get('site.beforeigner'); ?>
                                </div>
                            </div>
                            <div class="property col">
                                <div class="circle">
                                    <img src="<?php echo e(asset("image/portfolio.svg")); ?>" alt="">
                                </div>
                                <div class="main-text text-center main-color">
                                    <?php echo app('translator')->get("site.portfolio"); ?>
                                </div>
                            </div>
                        </div>
                        <div
                            style="display: flex; flex-wrap: wrap; flex-direction: row; margin-left: -15px; margin-right: -15px; padding: 0 10px">

                            <div class="property col">
                                <div class="circle">
                                    <img src="<?php echo e(asset("image/clock-fill.svg")); ?>" alt="">
                                </div>
                                <div class="main-text text-center main-color">
                                    <?php echo app('translator')->get('site.want'); ?>
                                </div>
                            </div>
                            <div class="property col">
                                <div class="circle">
                                    <img src="<?php echo e(asset("image/quest.svg")); ?>" alt="">
                                </div>
                                <div class="main-text text-center main-color">
                                    <?php echo app('translator')->get('site.select_university'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="main-header text-white header-lg header-anim"
                         data-aos="fade-up"><?php echo app('translator')->get('site.join'); ?></div>
                    <p class="p second-color mt-5 " data-aos-delay="200" data-aos="zoom-out">
                        <?php echo app('translator')->get('site.mehmon'); ?>
                    </p>

                    <div class="mt-5">
                        <a href="" class="mainBtn fill"><?php echo app('translator')->get('site.write_course'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="p-100 mt-5" style="padding-right: 15px">

        <div class="row">
            <div class="col-lg-5">
                <div class="main-header header-anim" data-aos="fade-up"><?php echo app('translator')->get('site.student_result'); ?></div>
                <div class="main-body" style="margin-top: 25px" data-aos="fade-up">
                    <?php echo app('translator')->get('site.after'); ?>
                </div>
            </div>
            <div class="col-lg-7 pr-0">
                <div class="owl-carousel student-home  owl-theme w-100">

                    <?php $__currentLoopData = \App\Models\Student::latest()->take(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="item p-lg-5">
                            <div class="student" data-aos="fade-up">
                                <div class="d-flex">
                                    <div class="student-avatar">
                                        <img src="<?php echo e(imagePath($item->image)); ?>" alt="">
                                    </div>
                                    <div style="margin-left: 20px">
                                        <div class="student-name"><?php echo e($item->fullname); ?></div>
                                        <div class="main-text t-mini main-color"><?php echo e($item->universitet); ?></div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between" style="margin-top: 36px">
                                    <div class="student-subject">IELTS <b><?php echo e($item->ielts); ?></b></div>
                                    <div class="student-subject"><?php echo e($item->main_subject); ?> <b><?php echo e($item->main_subject_ball); ?>

                                            /30</b></div>
                                    <div class="student-subject">DTM<b><?php echo e($item->dtm); ?> ball</b></div>
                                </div>
                                <div class="text" style="margin-top: 25px">
                                    <?php echo e($item->comment); ?>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="item p-lg-5">
                        <div class="student" data-aos="fade-up">
                            <div class="d-flex">
                                <div class="student-avatar">
                                    <img src="image/group-students-posing-table%201.png" alt="">
                                </div>
                                <div style="margin-left: 20px">
                                    <div class="student-name">Jurabek Umarov</div>
                                    <div class="main-text t-mini main-color">TDIU Studenti</div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between" style="margin-top: 36px">
                                <div class="student-subject">IELTS <b>7.5</b></div>
                                <div class="student-subject">Matematika <b>27/30</b></div>
                                <div class="student-subject">DTM<b>184 ball</b></div>
                            </div>
                            <div class="text" style="margin-top: 25px">
                                Men 2 yil davomida Kompass o’qiv markazida tayyorlandim va bilimim ancha yuqorilandi. Va
                                hamma repetitorlar o’z ustimda ishlash katta xissa qo’shishdi.
                            </div>
                        </div>
                    </div>
                </div>

                <div style="margin-left: 60px">
                    <a href="" class="mainBtn fill"><?php echo app('translator')->get('site.more'); ?></a>
                </div>
            </div>
        </div>


    </div>


    <div class="p-100" style="padding-top: 0">

        <div class="mega-header text-center" data-aos="fade-up"><?php echo app('translator')->get('site.ready'); ?></div>

        <div class="row">

            <?php $__currentLoopData = \App\Models\Subject::latest()->take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-4" data-aos="fade-up">
                    <div class="subject-1">
                        <div class="main-text text-uppercase main-color text-center"><?php echo e($item->name); ?></div>
                        <div class="subject-name"><?php echo e($item->sum); ?> SUM <span style="opacity: 0.7; font-size: 26px">/oy</span>
                        </div>
                        <?php if($item->property1): ?>
                        <div class="var"><img src="<?php echo e(asset("image/check-circle.svg")); ?>" alt="">
                            <div class="var-text"><?php echo e($item->property1); ?></div>
                        </div>
                        <?php endif; ?>
                        <?php if($item->property2): ?>
                            <div class="var"><img src="<?php echo e(asset("image/check-circle.svg")); ?>" alt="">
                                <div class="var-text"><?php echo e($item->property2); ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if($item->property3): ?>
                            <div class="var"><img src="<?php echo e(asset("image/check-circle.svg")); ?>" alt="">
                                <div class="var-text"><?php echo e($item->property3); ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if($item->property4): ?>
                            <div class="var"><img src="<?php echo e(asset("image/check-circle.svg")); ?>" alt="">
                                <div class="var-text"><?php echo e($item->property4); ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if($item->property5): ?>
                            <div class="var"><img src="<?php echo e(asset("image/check-circle.svg")); ?>" alt="">
                                <div class="var-text"><?php echo e($item->property5); ?></div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12">
                <div class="text-center mt-80">
                    <a href="" class="mainBtn fill"><?php echo app('translator')->get('site.write_course'); ?></a>

                </div>
            </div>
        </div>


    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Compass\resources\views/site/index.blade.php ENDPATH**/ ?>