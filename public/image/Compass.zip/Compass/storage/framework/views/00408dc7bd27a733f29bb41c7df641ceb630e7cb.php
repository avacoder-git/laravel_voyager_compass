<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/news.css")); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>






    <div class="p-100">

        <div class="main-header" data-aos="fade-up">Yangiliklar</div>

        <div class="pt-80">
            <div class="subject-name second-color"><?php echo e($news->title); ?>

            </div>
        </div>

        <div class="content">
            <?php echo $news->body; ?>


        </div>


        <div class="pt-80 ml-auto text-right main-text second-color">
            <?php echo e(changeDateFormate($news->created_at)); ?>

        </div>

        <div class="container-fluid p-lg-0">
            <div class="row">
                <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12" data-aos="fade-up">
                        <a href="<?php echo e(route("news.index", $new)); ?>" class="d-block">
                            <div class="news row">
                                <div class="new-img col-lg-4 p-0"><img src="<?php echo e(asset("storage/$new->thumbnail")); ?>"
                                                                       alt=""></div>
                                <div class="news-body col-lg-8">
                                    <div class="news-header"><?php echo e($new->title); ?></div>
                                    <div class="news-text">
                                        <?php echo Str::limit($new->body, 200); ?>

                                    </div>

                                    <div class="news-footer">
                                        <div class="main-text batafsil third-color">Batafsil</div>
                                        <div class="p third-color">
                                            <?php echo e(changeDateFormate($new->created_at)); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script>
        if ($(window).width() < 600) {
            $('.content img').attr("width", "100%")
            $('.content img').attr("height", "")
        }


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Compass\resources\views/site/news/index.blade.php ENDPATH**/ ?>