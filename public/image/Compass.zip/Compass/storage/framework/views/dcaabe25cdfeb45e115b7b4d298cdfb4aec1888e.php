<?php $__env->startSection("content"); ?>


    <div class="pt-lg-5 pt-3">
        <div class="container ">
            <div class="main-header text-center"><?php echo app('translator')->get('site.register'); ?></div>

            <div class="pt-lg-5">
                <div class="d-lg-flex">
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('register')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="items" value="<?php echo e(del_element_from_array($course->id, $courses)); ?>">
                            <button class="fan fan-<?php echo e($course->id); ?>" data-id="<?php echo e($course->id); ?>">
                                <?php echo e($course->name); ?> <img src="<?php echo e(asset('image/x-circle.svg')); ?>" alt="">
                            </button>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('courses.browse')); ?>" class="add-fan"><?php echo app('translator')->get('site.add_subject'); ?></a>
                </div>
            </div>

            <form action="<?php echo e(route("register.post")); ?>" method="post" class="register-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="items" value="<?php echo e(del_element_from_array('', $courses)); ?>">
                <div class="">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <label for="name" class="main-text main-color d-block"><?php echo app('translator')->get('site.name'); ?>*</label>
                                <input type="text" id="name" required name="name">
                            </div>
                            <div class="col-lg-6">
                                <label for="lastname" class="main-text main-color d-block"><?php echo app('translator')->get('site.lastname'); ?>*</label>
                                <input type="text" required id="lastname" name="lastname">
                            </div>
                            <div class="col-lg-6">
                                <label for="phone" class="main-text main-color d-block"><?php echo app('translator')->get('site.phone'); ?>*</label>
                                <input type="text" required id="phone" name="phone" placeholder="+998 (90) 123-45-67">
                            </div>
                            <div class="col-lg-6">
                                <label for="address" class="main-text main-color d-block"><?php echo app('translator')->get('site.address'); ?>*</label>
                                <input type="text" required id="address" name="address" placeholder="14 Daha">
                            </div>
                            <div class="col-lg-12">
                                <label for="info" class="main-text main-color d-block"><?php echo app('translator')->get('site.info_yourself'); ?></label>
                                <textarea
                                    placeholder="<?php echo app('translator')->get('site.yourself_placeholder'); ?>"
                                    name="description" id="info" cols="30" rows="5"></textarea>
                            </div>

                            <div class="mt-60 w-100 mb-5 row justify-content-center">
                                <a href="<?php echo e(route('register')); ?>" style="text-decoration: underline"
                                   class="d-block my-auto ml-auto mr-5 main-text text-danger"><?php echo app('translator')->get('site.cancel'); ?></a>
                                <button type="submit" class="mainBtn fill ml-5 mr-auto d-block"><?php echo app('translator')->get('site.send'); ?></button>

                            </div>
                        </div>
                    </div>
                </div>

            </form>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        $('.fan').click(function (){
            var storedArray =[0];//no brackets
            storedArray = storedArray.concat(JSON.parse(sessionStorage.getItem("items"))??[0]);//no brackets
            var id = $(this).data('id')
            storedArray = del_element_from_array(id, storedArray)
            sessionStorage.setItem("items", JSON.stringify(storedArray))
        })

        function del_element_from_array(id, arr){
            var index = arr.indexOf(id)
            var arr1 = [0]
            arr2 = arr.splice(index)
            return arr1.concat(arr2)
        }
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Compass\resources\views/site/register.blade.php ENDPATH**/ ?>