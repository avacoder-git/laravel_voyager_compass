<?php $__env->startSection('content'); ?>

    <div class="p-100">
        <div class="main-header"><?php echo app('translator')->get('site.student_result'); ?></div>

        <div class="dropdown result-year">
            <button class="btn main-text shadow-none main-color dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                <?php echo e($year); ?> <?php echo app('translator')->get('site.result'); ?>
            </button>
            <div class="dropdown-menu bg-main" aria-labelledby="dropdownMenu2">
                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('results.browse')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="year" value="<?php echo e($item); ?>">
                        <button class="dropdown-item bg-main color-yellow main-text" type="submit"><?php echo e($item); ?></button>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="main-text m-4 main-color"><?php echo e(($page-1)*9+1); ?>-<?php echo e(($page-1)*9 + count($students)); ?> / <?php echo e(count($all)); ?></div>
        <div class="container-fluid p-lg-0">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-12" data-aos="fade-up">
                        <div class="student-result">
                            <div class="container-fluid">
                                <div class="row justify-content-between">
                                    <div class="col-lg-3 col-6">
                                        <div class="student-img"><img src="<?php echo e(imagePath($student->image)); ?>" alt=""></div>
                                    </div>
                                    <div class="col-lg-4 col-6">
                                        <div class="owl-carousel student-tests owl-theme">
                                            <?php $__currentLoopData = json_decode($student->results); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="item">
                                                    <a href="<?php echo e(imagePath($test)); ?>" download  class="d-block">
                                                        <div class="test-sheet">
                                                            <span class="title-hover"><i class="fa fa-download" aria-hidden="true"></i></span>

                                                            <img src="<?php echo e(imagePath($test)); ?>" alt="">
                                                        </div>
                                                    </a>
                                                </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 ">

                                        <div class="result-info">
                                            <div class="student-name"><?php echo e($student->fullname); ?></div>
                                            <div class="student-university">
                                                <?php echo e($student->universitet); ?>

                                            </div>
                                            <div class="student-text p">
                                                <?php echo e($student->comment); ?>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="main-text main-color container text-center mt-5"><?php echo app('translator')->get('site.nothing'); ?></div>

                <?php endif; ?>

            </div>
        </div>

        <div class="paginations">
            <?php echo e($students->appends(['year' => $year])->links()); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>






<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\Compass\resources\views/site/results.blade.php ENDPATH**/ ?>