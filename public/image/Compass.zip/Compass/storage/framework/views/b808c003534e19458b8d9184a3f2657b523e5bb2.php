<!-- This is NAVBAR here!-->
<nav  class="navbar  navbar-expand-lg navbar-dark">
    <button class="navbar-toggler collapsed border-0" type="button" data-toggle="collapse"
            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true"
            aria-label="Toggle navigation">
        <span class="icon-bar top-bar"></span>
        <span class="icon-bar middle-bar"></span>
        <span class="icon-bar bottom-bar"></span>
    </button>
    <a class="navbar-brand" data-aos="fade-right"
       data-aos-easing="ease-in-sine"  href="/"><img height="90" src="<?php echo e(asset('image/Logo.png')); ?>" alt=""></a>
    <a class="contactBtnSm fill" href="<?php echo e(route('register')); ?>"><?php echo app('translator')->get('site.contact'); ?></a>


    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav">
            <li class="nav-item <?php echo e(set_active('about')); ?>"  data-aos="fade-right"
                data-aos-easing="ease-in-sine"  data-aos-delay="100">
                <a class="nav-link"  href="<?php echo e(route("about")); ?>"><?php echo app('translator')->get('site.about'); ?></a>
            </li>
            <li class="nav-item <?php echo e(set_active('news')); ?>"  data-aos="fade-right"
                data-aos-easing="ease-in-sine"  data-aos-delay="150">
                <a class="nav-link" href="<?php echo e(route("news.browse")); ?>"><?php echo app('translator')->get('site.news'); ?></a>
            </li>
            <li class="nav-item <?php echo e(set_active('courses')); ?>"  data-aos="fade-right"
                data-aos-easing="ease-in-sine"  data-aos-delay="200">
                <a class="nav-link" href="<?php echo e(route("courses.browse")); ?>"><?php echo app('translator')->get('site.course'); ?></a>
            </li>
            <li class="nav-item <?php echo e(set_active('results')); ?>"  data-aos="fade-right"
                data-aos-easing="ease-in-sine"  data-aos-delay="250">
                <a class="nav-link" href="<?php echo e(route("results.browse")); ?>"><?php echo app('translator')->get('site.results'); ?></a>
            </li>

            <li class="nav-item dropdown lang"  data-aos="fade-right"
                data-aos-easing="ease-in-sine" data-aos-delay="300" >
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                   aria-expanded="false">
                    <?php echo e(app()->getLocale()); ?>

                </a>
                <div class="dropdown-menu border-white shadow bg-main" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item bg-main text-white" href="<?php echo e(changeLang('uz')); ?>">Uzb</a>
                    <a class="dropdown-item bg-main text-white" href="<?php echo e(changeLang('ru')); ?>">Rus</a>
                </div>
            </li>
            <li class="nav-item contactBtnLg"  data-aos-delay="350" data-aos="fade-right"
                data-aos-easing="ease-in-sine" >
                <a href="<?php echo e(route('register')); ?>" class="nav-link fill mainBtn"><?php echo app('translator')->get('site.contact'); ?></a>
            </li>
        </ul>
    </div>
</nav>
<!-- This is the end of the NAVBAR here!-->
<?php /**PATH C:\OpenServer\domains\Compass\resources\views/components/navbar.blade.php ENDPATH**/ ?>