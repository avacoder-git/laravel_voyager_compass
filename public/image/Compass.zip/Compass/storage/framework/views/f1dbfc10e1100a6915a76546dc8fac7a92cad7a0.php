<footer class="bg-main">

    <div class="p-100" style="padding-top: 30px">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 p-lg-0">
                    <a href=""><img src="<?php echo e(asset("image/logo-white.svg")); ?>" alt=""></a>
                    <div class="footer-left">

                        <a href="tel: <?php echo e(setting('site.phone1')); ?>" class="p footer-link"><?php echo e(setting('site.phone1')); ?></a>
                        <a href="tel: <?php echo e(setting('site.phone2')); ?>" class="p  footer-link"><?php echo e(setting('site.phone2')); ?></a>
                        <a href="" class="p  footer-link"><?php echo e(setting('site.address1')); ?></a>
                        <a href="" class="p  footer-link"><?php echo e(setting('site.address2')); ?></a>
                    </div>
                </div>
                <div class="col-lg-9 p-0">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-3">
                                <div class="footer-header"><?php echo app('translator')->get('site.center'); ?></div>
                                <a href="<?php echo e(route('about')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.about'); ?></a>
                                <a href="<?php echo e(route('about')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.comments'); ?> </a>
                                <a href="<?php echo e(route('about')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.students'); ?></a>

                            </div>

                            <div class="col-lg-3">
                                <div class="footer-header"><?php echo app('translator')->get('site.course'); ?></div>
                                <a href="<?php echo e(route('courses.browse')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.tutors'); ?></a>
                                <a href="<?php echo e(route('courses.browse')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.course'); ?> </a>
                                <a href="<?php echo e(route('courses.browse')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.president'); ?> </a>

                            </div>
                            <div class="col-lg-3">
                                <div class="footer-header"><?php echo app('translator')->get('site.news'); ?></div>
                                <a href="<?php echo e(route('news.browse')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.tadbirlar'); ?></a>
                                <a href="<?php echo e(route('news.browse')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.results'); ?></a>
                                <a href="<?php echo e(route('news.browse')); ?>" class="p  footer-link"><?php echo app('translator')->get('site.actions'); ?></a>

                            </div>
                            <div class="col-lg-3">
                                <div class="footer-header"><?php echo app('translator')->get('site.social_networks'); ?></div>
                                <a href="<?php echo e(setting('site.telegram')); ?>" class="p  footer-link"><i class="fab fa-telegram text-white" style="margin-right: 10px"></i>Telegram</a>
                                <a href="<?php echo e(setting('site.youtube')); ?>" class="p  footer-link"><img src="<?php echo e(asset("image/youtube.svg")); ?>"
                                                                       style="margin-right: 10px" alt="">YouTube</a>
                                <a href="<?php echo e(setting('site.instagram')); ?>" class="p  footer-link"><img src="<?php echo e(asset("image/instagram.svg")); ?>"
                                                                       style="margin-right: 10px" alt="">Instagram</a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</footer>
<?php /**PATH C:\OpenServer\domains\Compass\resources\views/components/footer.blade.php ENDPATH**/ ?>